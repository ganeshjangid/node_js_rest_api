Go to this site to make and edit your api doc

https://editor.swagger.io//?_ga=2.73171923.1720213080.1513971186-1650799174.1513971186#/